import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Queue;

public class Solver {
    private SearchNode searchNode;
    private int moves;

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) throw new IllegalArgumentException();
        searchNode = new SearchNode(initial, 0, null);
        moves = 0;
        solution();
    }

    public boolean isSolvable() {
        int n = searchNode.board.dimension();
        int[][] board = getBoardArray();
        // Flatten the 2D puzzle into a 1D array
        int[] flatBoard = new int[board.length * board.length];
        int index = 0;
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                flatBoard[index++] = board[i][j];
            }
        }

        // Count the number of inversions
        int inversions = 0;
        for (int i = 0; i < flatBoard.length; i++) {
            for (int j = i + 1; j < flatBoard.length; j++) {
                if (flatBoard[i] > flatBoard[j] && flatBoard[i] != 0 && flatBoard[j] != 0) {
                    inversions++;
                }
            }
        }

        // If the grid size is odd, the puzzle is solvable if the number of inversions is even
        if (board.length % 2 != 0) {
            return inversions % 2 == 0;
        }
        // If the grid size is even, the puzzle is solvable if both conditions are met
        else {
            int blankRow = findBlankRow(board);
            return (inversions % 2 == 1 && blankRow % 2 == 0) || (inversions % 2 == 0
                    && blankRow % 2 == 1);
        }
    }

    private int findBlankRow(int[][] board) {
        // Find the row index of the blank tile (0) in the puzzle
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                if (board[i][j] == 0) {
                    return i;
                }
            }
        }
        return -1; // return -1 if not found (should not happen in a valid puzzle)
    }


    // // is the initial board solvable? (see below)
    // public boolean isSolvable() {
    //     int n = searchNode.board.dimension();
    //     int[][] board = getBoardArray();
    //     int[] flatBoard = flat(board);
    //     int inversions = getInversionsCount(flatBoard);
    //
    //     if (n % 2 == 0) {
    //         int blankRow = n - getBlankRow(board);
    //         return (inversions % 2 == 0) == ((blankRow + 1) % 2 == 0);
    //     }
    //     else {
    //         return inversions % 2 == 0;
    //     }
    //
    //     // int blankRow = getBlankRow(board);
    //     //
    //     // if (n % 2 == 1) return inversions % 2 == 0;
    //     // return (inversions % 2 == 0) && (((n - blankRow) % 2 == 0) == ((inversions + blankRow) % 2
    //     //         == 1));
    // }
    //
    // private int[] flat(int[][] board) {
    //     int n = board.length;
    //     int m = board[0].length;
    //     int[] flattened = new int[n * m];
    //     int index = 0;
    //     for (int i = 0; i < n; i++) {
    //         for (int j = 0; j < m; j++) {
    //             flattened[index++] = board[i][j];
    //         }
    //     }
    //     return flattened;
    // }
    //
    // private int getInversionsCount(int[] array) {
    //     int inversions = 0;
    //     for (int i = 0; i < array.length; i++)
    //         for (int j = i + 1; j < array.length; j++)
    //             // Value 0 is used for empty space
    //             if (array[i] != 0 && array[j] != 0 && array[i] > array[j])
    //                 inversions++;
    //     return inversions;
    // }
    //
    //
    // private int getBlankRow(int[][] board) {
    //     for (int i = board.length - 1; i >= 0; i--) {
    //         for (int j = 0; j < board[i].length; j++) {
    //             if (board[i][j] == 0) return i;
    //         }
    //     }
    //     return -1;
    // }

    private int[][] getBoardArray() {
        String[] rows = searchNode.board.toString().split("\n"); // Split by newline character
        int n = Integer.parseInt(rows[0]); // Get the size of the puzzle
        int[][] flatBoard = new int[n][n]; // Initialize the 2D array

        for (int i = 1; i <= n; i++) {
            String[] values = rows[i].trim().split("\\s+"); // Split each row by whitespace
            for (int j = 0; j < n; j++) {
                flatBoard[i - 1][j] = Integer.parseInt(
                        values[j]); // Parse the integers and store in the array
            }
        }
        return flatBoard;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable()) return -1;
        return moves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        MinPQ<SearchNode> priorityQueue = new MinPQ<>();
        Queue<Board> result = new Queue<>();

        if (searchNode.previous == null) priorityQueue.insert(searchNode);


        while (true) {
            SearchNode node = priorityQueue.delMin();
            result.enqueue(node.board);

            if (node.board.isGoal()) return result;

            moves++;
            for (Board neighbor : node.board.neighbors()) {

                // if (node.board.equals(neighbor) || (node.previous != null
                //         && node.previous.board.equals(neighbor))) continue;
                if (help(neighbor, priorityQueue)) continue;
                else {
                    int priority = neighbor.manhattan() + moves();

                    SearchNode neighborSearchNode = new SearchNode(neighbor, priority, node);
                    priorityQueue.insert(neighborSearchNode);
                }

            }
        }
    }


    private boolean help(Board neighborBoard, MinPQ<SearchNode> priorityQueue) {
        for (SearchNode n : priorityQueue) {
            if (n.board.equals(neighborBoard)) return true;
        }
        return false;
    }

    public static void main(String[] args) {

    }
}