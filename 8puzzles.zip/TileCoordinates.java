public class TileCoordinates {
    int row;
    int col;

    public TileCoordinates(int row, int col) {
        this.row = row;
        this.col = col;
    }
}